#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define BUFFER_SIZE 1000

void deleteLine(FILE *src, FILE *temp, const int line);


int id_customer,items_number,new_price,total;
char name[255],drink[255];
void order_page();
void Customer_page2();

void order_search_page();
void Staff_options_page();
void Regriested_Customer_login_page();
void Customer_page2();

void staff_login_page();
void order_page();




void New_Customer_page(){  // New_Customer_pag



        FILE *fp;
        char ids[255];
        char name[255];
        char password[255];
        char address[255];
        char sex[255];
        char phone_number[255];
        char Email[255];
        int id, i;
        fp=fopen("Account.txt","r+");
        char new_name[20],new_password[50],new_address[50],new_sex[10],new_phone[15],new_email[50];
        printf("\nEnter New Username:\n");
        scanf("%s",&new_name);  
        printf("\nEnter New Password:\n");
        scanf("%s",&new_password);   
        printf("\nEnter Your Addrress:\n");
        scanf("%s",&new_address); 
        printf("\nEnter Your Sex(Male ot Female):\n");
        scanf("%s",&new_sex);  
        printf("\nEnter Contact Number:\n");
        scanf("%s",&new_phone);   
        printf("\nEnter Your Email Addrress:\n");
        scanf("%s",&new_email);   
        for (i =0; i<=100;i++)
        {
          fscanf(fp, "%s %s %s %s %s %s %s", ids, name, password, address, sex, phone_number, Email);
          id = atoi(ids);
        }    
        int newid  = id + 1;    

        fprintf(fp,"\n%d %s %s %s %s %s %s",newid,new_name,new_password,new_address,new_sex,new_phone,new_email);
        fclose(fp);
        printf("Your account is created!!!....\n");
        printf("Your username is: %s\n",new_name);
        printf("Your password is: %s\n",new_password);
        printf("Your address is: %s\n",new_address);
        printf("Your sex is: %s\n",new_sex);
        printf("Your contact number is: %s\n",new_phone);
        printf("Your Email address is: %s\n",new_email);
        Regriested_Customer_login_page();                
                
                         

    



}


int main()
 {   

    int option1;
    int C[]={1,2,3,4,5};
    int i;
    printf("\t      -------------------------------------\n");
    printf("\t----------------------Main Page----------------------\n");
    printf("\t      -------------------------------------\n");
    printf("Write option number (1 , 2 , 3 or 4):\n");
    printf("1.Staff\n2.Regriested Customer\n3.New Customer\n4.Exit\n");
    printf("-------------------------------------\n");
    scanf("%d",&option1);
    printf("-------------------------------------\n\n");
    switch (option1)
    {
     case 1:
        staff_login_page();
        break;
     case 2:
        Regriested_Customer_login_page();
        break;    

     case 3:
        New_Customer_page();
        break;   

     case 4:
        exit(1);
        break;        
    
     default:
        exit(1);
        break;3
    }

    

    return 0;
}




void deleteLine(FILE *src, FILE *temp, const int line){   //Regriested_Customer_page
   char buffer[BUFFER_SIZE];
   int count = 1;
   while ((fgets(buffer, BUFFER_SIZE, src)) != NULL){
      if (line != count)
         fputs(buffer, temp);

      else 
       fputs("\n",temp); 
         
      count++;
   }

}   
void order_page_2(){


    int option1,item[10];
    FILE *fp, *ap;
    int i,id,c,items;
    char price[255],ids[13],quantity[4],drnk_id[44];
    printf("Enter number of item to order it:\n");
    scanf("%d",item);
    printf("How many one you want?\n");
    scanf("%s",quantity);
    ap=fopen("Menue.txt","r");
    fp=fopen("Order.txt","r+");
    for (i =0; i<=100;i++)
     {
        scanf(fp,"%d %d %s %s %s %s",ids,id_customer,name,drink,price,quantity);
        id = atoi(ids);

        
     }      
    int newid  = id + 1;   
    printf("%d",newid);



    for (i =0; i<=0;i++)
     { 
        fscanf(ap, "%s %s %s", drnk_id, drink, price);

     }
    new_price = atoi(price);
    items_number = atoi(quantity);
    total = new_price * items_number; 



    


    char option3[16],option4[12];
    printf("\t      -------------------------------------\n");
    printf("\t----------------------(Paymnet Page)----------------------\n");
    printf("\t      -------------------------------------\n");
    printf("Enter your card number: ");
    scanf("%s",&option3);
    printf("Enter CV number: ");
    scanf("%s",option4);
    printf("Your order has be placed succecfully\n ");
    printf("\t      -------------------------------------\n");
    printf("\t----------------------(Receipt)----------------------\n");
    printf("\t      -------------------------------------\n");
    printf("\t----------------------(Receipt ID:%d)----------------------\n",newid);
    printf("Drink Name: %s   \tPrice: %d    \tQuantity: %d    \tTotal:%d\n",drink,new_price,items_number,total);
    printf("\n-----------------------------------------------\n");
    for (i =0; i<=0;i++)
     { 
        
        fprintf(fp,"%d %d %s %s %s %s\n",newid,id_customer,name,drink,price,quantity);
        printf("\nDone\n");
     }   
        
    fclose(fp);
    fclose(ap);
   

    printf("\nDo you want to order anything(1 , 2)?");
    printf("\n-------\n1.Yes\n-------\n2.No\n-------\n");
    scanf("%d",&option1);
    switch (option1)
     {
        case 1:

         order_page();
         break;

        case 2:
           Customer_page2();
         break;
 
        default:
          Customer_page2();
    
        }
}
void order_page(){
    int option1,item[10];
    FILE *fp, *ap;
    int i,id,c,items;
    char drink[255],price[255],ids[13],items_number[10];
    printf("\t      -------------------------------------\n");
    printf("\t----------------------(Order Page)----------------------\n");
    printf("\t      -------------------------------------\n");
    printf("Write option number (1 , 2 or 3):\n");
    printf("1.See The menue\n2.Start order\n3.Back\n");
    printf("-------------------------------------\n");
    scanf("%d",&option1);
    printf("-------------------------------------\n");
    switch (option1)
    {
     case 1:
        printf("\t--------------------------------\n");
        printf("\t---------------(The menue)-----------------\n");
        printf("\t--------------------------------\n"); 
        printf("Drink   Price(RM)\n");
        ap=fopen("Menue.txt","r");
        for (i =0; i<=100;i++)
        { 
        fscanf(ap, "%s %s %s", ids, drink, price);
        id = atoi(ids);
        }
        c = id -1;
        fclose(ap);
        fp=fopen("Menue.txt","r");
        for (i =0; i<=c;i++)
        { 
        fscanf(fp, "%s %s %s", ids, drink, price);
        printf("\n%s.%s    %s\n",ids,drink,price);
        }
        fclose(fp);
        order_page();
        break;
     case 2:


        order_page_2();       
        break;    

     case 3:
        Customer_page2();
        break;        
    
     default:
        
        printf("Choose available option\n");
        printf("-------------------------------------\n");
        order_page();
        break;
    }
    
}
void Customer_page2(){  

    int option3;
    FILE *src;
    FILE *temp;
    int line;
    printf("Write option number (1 , 2 , 3 or 4):\n");
    printf("1.Modify your presonal profile\n2.Order and Pay\n3.Cancel your orders\n4.Exit\n");
    printf("-------------------------------------\n");
    scanf("%d",&option3);
    printf("-------------------------------------\n");
    switch (option3)
    {
     case 1:
        printf("\t--------------------------------\n");
        printf("\t---------------(The menue)-----------------\n");
        printf("\t--------------------------------\n");
        printf("Drink              Price(RM)\n1.Drip Cofee  10              2.Espresso   13\n3.Amreciano   15              4.Macchiato   13\n5.Cortado   13              6.Cappuccinno   13\n7.Latte   13              8.Mocha   13\n9.Cold Brew   13              10.Tea   13\n11.Orange Juice   13              12.Water   5\n");
        break;
     case 2:
        order_page();
        break;    

     case 3:

        
        src=fopen("Order.txt","r");
        temp = fopen("delete.tmp","w");
        printf("\nEnter Receipt ID:");
        scanf("%d",&line);

        rewind(src);
        deleteLine(src, temp, line);
        fseek(temp, 0, SEEK_END);
        fclose(src);
        fclose(temp);
        remove(src);
        rename("delete.tmp","Order.txt");
        Customer_page2();
        


        break;        
    

     case 4:
      exit(1);
      break;
     default:
        
        printf("Choose available option\n");
        printf("-------------------------------------\n");
        Customer_page2();

        break;
    }


}    
void Regriested_Customer_login_page(){   
    char username[255];
    char password[255];
    FILE *fp;
    char ids[255];
    
    char password_1[255];
    char address[255];
    char sex[255];
    char phone_number[255];
    char Email[255];
    int i, pass, pass1;    
    fp=fopen("Account.txt","r");
    printf("\t          -------------------------------------\n");
    printf("\t----------------------(Welocome to our shop)----------------------\n");
    printf("\t          -------------------------------------\n");
    printf("Enter Username:\n");
    scanf("%s",&username);
    printf("Enter Password:\n");
    scanf("%s",&password);
    for (i =0; i<=100;i++)
        {
          fscanf(fp, "%s %s %s %s %s %s %s", ids, name, password_1, address, sex, phone_number, Email);
          pass= atoi(password);
          pass1= atoi(password_1);
          printf("\n%s",password);
          printf("\n%s",password_1);
          if(pass == pass1)
          { 
            id_customer = atoi(ids);
            printf("\n-----------------------------------------------------------\n");
            printf("\n------------------(You login sucssefully)------------------\n");
            printf("\n-----------------------------------------------------------\n");
            Customer_page2();
            break;

          } 

          else if(pass != pass1){
        
          printf("\nYour account is not found....\nTry again or create new account if you don't have regristed account\n");
          Regriested_Customer_login_page();
          

         
             }
          
          
        }   

 
  
          

}



void order_search_page(){     //Staff_login_page
 printf("\n\t      -------------------------------------\n");
    printf("\t----------------------(Search Page)----------------------\n");
    printf("\t      -------------------------------------\n");   
 FILE *fp;
 char id[23],customer[33],drink[23],price[33],items_number[22];
 int i;
 fp =fopen("Order.txt","r");
 for (i =0; i<=100;i++)
  {
    
    fscanf(fp,"%s %s %s %s %s\n",id,customer,drink,price,items_number);
    printf("-------------------------------------");
    printf("\nCustomwr ID:%s\t Customer Name:%s \n------------\nDrink Name:%s   Price(Rm):%s   Quantity:%s\n",id,customer,drink,price,items_number);

  } 

}
void Staff_options_page() { 
    int i,option2,id;
    FILE *afp; 
    char drink_name[22],prcie[22],drink_id[22];


    printf("\t      -------------------------------------\n");
    printf("\t----------------------(Staff Page)----------------------\n");
    printf("\t      -------------------------------------\n");
    printf("-------------------------------------\n");
    printf("Write option number (1 , 2 , 3 or 4):\n");
    printf("-------------------------------------\n");
    printf("1.Add new item to the menue\n2.Update the menu item\n3.Delete an item from the menue\n4.Create new customer\n5.Search for any customer order based on customer ids\n6.Exit\n");
    printf("-------------------------------------\n");
    scanf("%d",&option2);
    printf("-------------------------------------\n");
    switch (option2)
    {
     case 1:
        afp=fopen("Menue.txt","r+");
        for (i =0; i<=100;i++)
        {
          fscanf(afp, "%s %s %s ", drink_id, drink_name, prcie);
          id = atoi(drink_id);
        }    
        int newid  = id + 1;           
        printf("\nEnter the name of the new item :\n");
        scanf("%s",&drink_name);  
        printf("\nEnter its price(RM):\n");
        scanf("%s",&prcie);   
        
        fprintf(afp,"\n%d %s %s ",newid,drink_name,prcie);
        printf("The new item has been added succecfully\n");
        fclose(afp);
        Staff_options_page();
        break;
     case 2:
        Regriested_Customer_login_page();
        break;    

     case 3:
      
        break;   

     case 4:
        

        break;   
     case 5:
        order_search_page();
    
        break; 
     case 6:
        exit(1);
        break;                               
    
     default:
        exit(1);
        break;
    }

    return ;


}
void staff_login_page(){

    int option1;
    FILE *fp;
    int i,New_pass,New_pass1,int_staff_username,int_staff_username2;
    char Staff_username[255],Staff_password[255],staff_id[233];
    char Staff_username1[255],Staff_password1[255];
    fp=fopen("Staff.txt","r");
    printf("\t          -------------------------------------\n");
    printf("\t----------------------(Staff login Page)----------------------\n");
    printf("\t          -------------------------------------\n");
    printf("Enter Username:\n");
    scanf("%s",&Staff_username);
    printf("Enter Password:\n");
    scanf("%s",&Staff_password);
    for (i =0; i<=100;i++)
        {
          fscanf(fp, "%s %s %s ", staff_id,Staff_username1,Staff_password1);
          New_pass= atoi(Staff_password);
          New_pass1=atoi(Staff_password1);
          int_staff_username = atoi(Staff_username1);
          int_staff_username2= atoi(Staff_username);
          if(int_staff_username == int_staff_username2)
          { 

            if(New_pass ==New_pass1){

                printf("\n-----------------------------------------------------------\n");
                printf("\n------------------(You login sucssefully)------------------\n");
                printf("\n-----------------------------------------------------------\n\n");
                Staff_options_page();
                break;


            }

            else{
                printf("Your username or password is not correct");
                exit(1);
                break;
                
            }

            printf("\n-----------------------------------------------------------\n");
            printf("\n------------------(You login sucssefully)------------------\n");
            printf("\n-----------------------------------------------------------\n\n");
            Staff_options_page();
            fclose(fp);
            break;
           }

          else{

            printf("Your username or password is not correct");
            exit(1);
            fclose(fp);
            break;
          }
        }

}




